<!DOCTYPE html>
<html>
<head>
    <title>Output Data Mahasiswa</title>
    <style type="text/css">
        body {
            font-family: Verdana, Arial, Helvetica, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 760px;
            margin: 20px auto;
            padding: 10px;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        h1 {
            text-align: center;
            color: #0077b6;
        }

        .output {
            margin-top: 20px;
            padding: 16px;
            background-color: #f2f2f2;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .output h3 {
            margin-top: 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Output Data Mahasiswa</h1>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Mendapatkan nilai yang dikirim melalui formulir
            $nama = $_POST["Nama"];
            $alamat = $_POST["Alamat"];
            $tpl = $_POST["TPL"];
            $tgl = $_POST["TGL"];
            $jeniskel = $_POST["jeniskel"];
            $pendidikan = $_POST["Pendidikan"];

            // Menampilkan output data mahasiswa
            echo "<div class='output'>";
            echo "<h3>Data Mahasiswa:</h3>";
            echo "<p>Nama: $nama</p>";
            echo "<p>Alamat: $alamat</p>";
            echo "<p>Tempat Lahir: $tpl</p>";
            echo "<p>Tanggal Lahir: $tgl</p>";
            echo "<p>Jenis Kelamin: $jeniskel</p>";
            echo "<p>Pendidikan: $pendidikan</p>";
            echo "</div>";

            // Menampilkan output hasil perhitungan
            echo "<div class='output'>";
            echo "<h3>Hasil Perhitungan:</h3>";

            if (isset($_POST['rumus'])) {
                $rumus = $_POST['rumus'];

                switch ($rumus) {
                    case "persegi_panjang_luas":
                        $panjang = $_POST["panjang"];
                        $lebar = $_POST["lebar"];
                        $luas = $panjang * $lebar;

                        echo "<p>Rumus: Luas Persegi Panjang</p>";
                        echo "<p>Panjang: $panjang</p>";
                        echo "<p>Lebar: $lebar</p>";
                        echo "<p>Luas: $luas</p>";
                        break;

                        case "persegi_panjang_keliling":
                            $panjang = $_POST["panjang"];
                            $lebar = $_POST["lebar"];
                            $keliling = 2 * ($panjang + $lebar);
                        
                            echo "<p>Rumus: Keliling Persegi Panjang</p>";
                            echo "<p>Panjang: $panjang</p>";
                            echo "<p>Lebar: $lebar</p>";
                            echo "<p>Keliling: $keliling</p>";
                            break;
                        

                    case "segitiga_luas":
                        $alas = $_POST["alas"];
                        $tinggi = $_POST["tinggi"];
                        $luas = 0.5 * $alas * $tinggi;

                        echo "<p>Rumus: Luas Segitiga</p>";
                        echo "<p>Alas: $alas</p>";
                        echo "<p>Tinggi: $tinggi</p>";
                        echo "<p>Luas: $luas</p>";
                        break;

                    case "segitiga_keliling":
                        $sisi1 = $_POST["sisi1"];
                        $sisi2 = $_POST["sisi2"];
                        $sisi3 = $_POST["sisi3"];
                        $keliling = $sisi1 + $sisi2 + $sisi3;

                        echo "<p>Rumus: Keliling Segitiga</p>";
                        echo "<p>Sisi 1: $sisi1</p>";
                        echo "<p>Sisi 2: $sisi2</p>";
                        echo "<p>Sisi 3: $sisi3</p>";
                        echo "<p>Keliling: $keliling</p>";
                        break;

                    default:
                        echo "<p>Tidak ada rumus yang dipilih.</p>";
                }
            } else {
                echo "<p>Tidak ada rumus yang dipilih.</p>";
            }

            echo "</div>"; // Close the output div
        }
        ?>
    </div>
</body>
</html>
