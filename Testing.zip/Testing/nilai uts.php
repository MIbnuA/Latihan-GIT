<!DOCTYPE html>
<html>
<head>
    <title>Hasil Nilai UTS Web Programming</title>
    <style type="text/css">
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 400px;
            margin: 0 auto;
            background-color: #f8f8f8;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #0077b6;
            text-align: center;
        }

        form {
            margin-top: 20px;
            text-align: center;
        }

        label {
            display: block;
            margin-bottom: 10px;
            color: #333;
            font-weight: bold;
        }

        input[type="number"],
        input[type="text"] {
            width: 100%;
            padding: 8px;
            border-radius: 4px;
            border: 1px solid #ccc;
            font-size: 16px;
        }

        input[type="submit"] {
            padding: 8px 20px;
            border-radius: 4px;
            background-color: #0077b6;
            color: #fff;
            border: none;
            font-size: 16px;
            cursor: pointer;
        }

        .result {
            margin-top: 20px;
            background-color: #fff;
            padding: 10px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h3 {
            margin-top: 0;
            color: #0077b6;
            font-size: 18px;
        }

        p {
            margin-bottom: 10px;
            color: #333;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Hasil Nilai UTS <br> Web Programming</h1>

        <?php
        // Mendapatkan nilai yang dikirim melalui formulir
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $nama = $_POST["nama_mahasiswa"];
            $kelas = $_POST["kelas"];
            $program_studi = $_POST["program_studi"];
            $pendidikan = $_POST["pendidikan"];
            $jenis_kelamin = $_POST["jenis_kelamin"];
            $nilai_uts = $_POST["nilai_uts"];

            // Menghitung status berdasarkan nilai UTS
            $status = ($nilai_uts >= 70) ? "Lulus" : "Tidak Lulus";

            // Menampilkan output
            echo "<div class='result'>";
            echo "<h3>Informasi:</h3>";
            echo "<p>Nama: $nama</p>";
            echo "<p>Kelas: $kelas</p>";
            echo "<p>Program Studi: $program_studi</p>";
            echo "<p>Pendidikan: $pendidikan</p>";
            echo "<p>Jenis Kelamin: $jenis_kelamin</p>";
            echo "<h3>Nilai UTS:</h3>";
            echo "<p>Nilai: $nilai_uts</p>";
            echo "<p>Status: $status</p>";
            echo "</div>";
        }
        ?>

        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
            <label for="nama_mahasiswa">Nama:</label>
            <input type="text" name="nama_mahasiswa" required>
            <br>
            <label for="kelas">Kelas:</label>
            <input type="text" name="kelas" required>
            <br>
            <label for="program_studi">Program Studi:</label>
            <input type="text" name="program_studi" required>
            <br>
            <label for="pendidikan">Pendidikan:</label>
            <input type="text" name="pendidikan" required>
            <br>
            <label for="jenis_kelamin">Jenis Kelamin:</label>
            <input type="text" name="jenis_kelamin" required>
            <br>
            <label for="nilai_uts">Nilai UTS:</label>
            <input type="number" name="nilai_uts" required>
            <br>
            <input type="submit" value="Submit">
        </form>
    </div>
</body>
</html>
