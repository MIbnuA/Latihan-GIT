<!DOCTYPE html>
<html>
<head>
    <title>Form Input Data Mahasiswa</title>
    <style type="text/css">
        body {
            font-family: Verdana, Arial, Helvetica, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 760px;
            margin: 20px auto;
            padding: 10px;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        h1 {
            text-align: center;
            color: #0077b6;
        }

        form {
            margin-top: 20px;
        }

        table {
            width: 100%;
        }

        table td {
            padding: 8px;
        }

        input[type="text"],
        textarea,
        select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="radio"] {
            margin-right: 5px;
        }

        input[type="submit"],
        input[type="reset"] {
            background-color: #0077b6;
            border: none;
            color: white;
            padding: 8px 16px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin-top: 10px;
            cursor: pointer;
            border-radius: 4px;
        }

        input[type="submit"]:hover,
        input[type="reset"]:hover {
            background-color: #023e8a;
        }

        .output {
            margin-top: 20px;
            padding: 16px;
            background-color: #f2f2f2;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .output h3 {
            margin-top: 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Form Input Data Mahasiswa</h1>
        <form action="tampilmahasiswa.php" method="POST">
            <table>
                <tr>
                    <td width="25%">Nama:</td>
                    <td><input type="text" name="Nama" maxlength="200" required></td>
                </tr>
                <tr>
                    <td>Alamat:</td>
                    <td><textarea rows="3" name="Alamat" required></textarea></td>
                </tr>
                <tr>
                    <td>Tempat Lahir:</td>
                    <td><input type="text" name="TPL" maxlength="30" required></td>
                </tr>
                <tr>
                    <td>Tanggal Lahir:</td>
                    <td><input type="text" name="TGL" maxlength="30" required></td>
                </tr>
                <tr>
                    <td>Jenis Kelamin:</td>
                    <td>
                        <input type="radio" name="jeniskel" value="Laki-Laki" required> Laki - Laki
                        <input type="radio" name="jeniskel" value="Perempuan" required> Perempuan
                        </td>
                </tr>
                <tr>
                    <td>Pendidikan:</td>
                    <td>
                        <select name="Pendidikan" required>
                            <option value="-">- Pendidikan -</option>
                            <option value="Sistem Informasi S1">Sistem Informasi S1</option>
                            <option value="Teknik Informatika S1">Teknik Informatika S1</option>
                            <option value="Teknik Mesin S1">Teknik Mesin S1</option>
                            <option value="Teknik Elektro S1">Teknik Elektro S1</option>
                            <option value="Komputer Akuntansi S1">Komputer Akuntansi S1</option>
                        </select>
                    </td>
                </tr>
            </table>
    <div class="container">
    <h1>Kalkulator Geometri</h1>
    <form method="post" action="tampilmahasiswa.php">
        <label for="rumus">Pilih rumus:</label>
        <select name="rumus" id="rumus" onchange="showInputForm()">
            <option value="">Pilih rumus</option>
            <option value="persegi_panjang_luas">Luas Persegi Panjang</option>
            <option value="persegi_panjang_keliling">Keliling Persegi Panjang</option>
            <option value="segitiga_luas">Luas Segitiga</option>
            <option value="segitiga_keliling">Keliling Segitiga</option>
        </select>

        <div id="input-form"></div>

        <tr>
                    <td colspan="2" style="text-align: center;">
                        <input type="submit" name="Submit" value="Submit">
                        <input type="reset" name="reset" value="Cancel">
                    </td>
                </tr>
     </form>
    </div>
    </form>
</div>

<script>
    function showInputForm() {
        var rumus = document.getElementById("rumus").value;
        var inputForm = document.getElementById("input-form");
        inputForm.innerHTML = "";

        switch (rumus) {
            case "persegi_panjang_luas":
                inputForm.innerHTML = `
                    <label for="panjang">Panjang:</label>
                    <input type="number" name="panjang" placeholder="Masukkan Nilai Angka 1" id="panjang" required>
                    <br>
                    <label for="lebar">Lebar:</label>
                    <input type="number" name="lebar" placeholder="Masukkan Nilai Angka ke 2" id="lebar" required>
                `;
                break;

            case "persegi_panjang_keliling":
                inputForm.innerHTML = `
                    <label for="panjang">Panjang:</label>
                    <input type="number" name="panjang" placeholder="Masukkan Nilai Angka 1" id="panjang" required>
                    <br>
                    <label for="lebar">Lebar:</label>
                    <input type="number" name="lebar" placeholder="Masukkan Nilai Angka ke 2" id="lebar" required>
                `;
                break;

            case "segitiga_luas":
                inputForm.innerHTML = `
                    <label for="alas">Alas:</label>
                    <input type="number" name="alas" placeholder="Masukkan Nilai Angka 1" id="alas" required
                    <br>
                    <label for="tinggi">Tinggi:</label>
                    <input type="number" name="tinggi" placeholder="Masukkan Nilai Angka 2" id="tinggi" required>
                `;
                break;

            case "segitiga_keliling":
                inputForm.innerHTML = `
                    <label for="sisi1">Sisi 1:</label>
                    <input type="number" name="sisi1" placeholder="Masukkan Nila Angka 1" id="sisi1" required>
                    <br>
                    <label for="sisi2">Sisi 2:</label>
                    <input type="number" name="sisi2" placeholder="Masukkan Nilai Angka ke 2" id="sisi2" required>
                    <br>
                    <label for="sisi3">Sisi 3:</label>
                    <input type="number" name="sisi3" placeholder="Masukkan Angka ke 3" id="sisi3" required>
                `;
                break;

            default:
                inputForm.innerHTML = "";
        }
    }
</script>
</body>
</html>