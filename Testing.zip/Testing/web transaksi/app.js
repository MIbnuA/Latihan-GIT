// Ambil elemen-elemen HTML yang diperlukan
const form = document.getElementById('transactionForm');
const itemNameInput = document.getElementById('itemName');
const itemPriceInput = document.getElementById('itemPrice');
const itemQuantityInput = document.getElementById('itemQuantity');
const transactionList = document.getElementById('transactionList');
const totalElement = document.getElementById('total');

// Inisialisasi variabel transaksi dan total
let transactions = [];
let total = 0;

// Fungsi untuk menampilkan daftar transaksi
function renderTransactions() {
  // Kosongkan daftar transaksi sebelumnya
  transactionList.innerHTML = '';

  // Iterasi setiap transaksi
  transactions.forEach(transaction => {
    const listItem = document.createElement('li');
    const itemName = document.createElement('span');
    const itemPrice = document.createElement('span');
    const itemQuantity = document.createElement('span');

    itemName.textContent = transaction.name;
    itemPrice.textContent = `Harga: ${transaction.price}`;
    itemQuantity.textContent = `Jumlah: ${transaction.quantity}`;

    listItem.appendChild(itemName);
    listItem.appendChild(itemPrice);
    listItem.appendChild(itemQuantity);

    transactionList.appendChild(listItem);
  });
}

// Fungsi untuk menghitung total transaksi
function calculateTotal() {
  total = transactions.reduce((acc, transaction) => {
    return acc + (transaction.price * transaction.quantity);
  }, 0);

  totalElement.textContent = `Total: ${total}`;
}

// Fungsi untuk menangani pengiriman formulir transaksi
function handleFormSubmit(event) {
  event.preventDefault();

  // Ambil nilai input
  const itemName = itemNameInput.value;
  const itemPrice = parseFloat(itemPriceInput.value);
  const itemQuantity = parseInt(itemQuantityInput.value);

  // Validasi input
  if (!itemName || !itemPrice || !itemQuantity) {
    alert('Mohon lengkapi semua field');
    return;
  }

  // Buat objek transaksi baru
  const newTransaction = {
    name: itemName,
    price: itemPrice,
    quantity: itemQuantity
  };

  // Tambahkan transaksi baru ke array transactions
  transactions.push(newTransaction);

  // Reset input form
  itemNameInput.value = '';
  itemPriceInput.value = '';
  itemQuantityInput.value = '';

  // Render ulang daftar transaksi dan hitung total
  renderTransactions();
  calculateTotal();
}

// Tambahkan event listener ke formulir transaksi
form.addEventListener('submit', handleFormSubmit);
